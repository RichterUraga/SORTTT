#include <iostream>
#include <vector>
#include<stdlib.h>
#include <chrono>
#include "sorter.h"
using namespace std;
using namespace std::chrono;

template <typename T>
void print_vec(vector<T>arr,int N)
{
  for(size_t i =0 ; i <arr.size()&&i<N; i++)
  {
    cout<<arr[i]<<"-";

  }
  cout<<endl;
}
int main (){

  //vector<int>arr_f;
  //vector<int>arr_2;
  //vector<int>arr_3;
  vector<int>arr_e;
  int count=100000;
  for (size_t i = 0 ; i<count; i++)
  {
  arr_e.push_back((int)rand()/100000);
  }
  auto inicio=high_resolution_clock::now();
  //BubbleSort<int>bubblesortt;
  //bubblesortt.sort(arr_2);
  cout<<"bubble sort<<endl"<<endl;
  //----------------------
  //InsertionSort<int>insert;
  //insert.sort(arr_3);
  //-----------------------
  //SelectionSort<int>selsort;
  //selsort.sort(arr_f);
  //-----------------------
  MergeSort<int>merge;
  merge.sort(arr_e);
  //-----------------------

  cout<<endl<<"Sorted"<<endl;
  //print_vec(arr_3,100000);
  //print_vec(arr_2,10);
  //print_vec(arr_f,100000);
  print_vec(arr_e,100000);
  auto fin=high_resolution_clock::now();
	auto tiempo=duration_cast<microseconds>(fin - inicio).count();
  cout<<"tiempo en micro segundos: "<<tiempo<<endl;
  return 0;

}
