#include<iostream>
using namespace std;
template <typename T>
class Sorter
{
    public:
    Sorter() {};
    ~Sorter() {};

    void swap(int i, int j, std::vector<T> &arr)
    {
        T aux = arr[i];
        arr[i] = arr[j];
        arr[j] = aux;
    };

    virtual void sort(std::vector<T> &arr) {};
};
template <typename T>
class InsertionSort : public Sorter<T>
{
    public:
    InsertionSort() {};
    ~InsertionSort() {};


    void sort(std::vector<T> &arr)
    {
        T key;
        for (size_t i = 0; i < arr.size(); i++)
        {
          key = arr[i];
          int j= i-1;
          while (j>=0&& arr[j]> key)
          {
            arr[j+1]= arr[j];
            j--;
          }
          arr[j+1]= key;
        }
    }       
};

