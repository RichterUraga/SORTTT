#include <iostream>
#include<vector>
#include<chrono>
using namespace std;
using namespace std::chrono;
void merge(int *,int, int , int );
void mergesort(int *arr, int low, int high)
{
    int mid;
    if (low < high){
        //divide the array at mid and sort independently using merge sort
        mid=(low+high)/2;
        mergesort(arr,low,mid);
        mergesort(arr,mid+1,high);
        //merge or conquer sorted arrays
        merge(arr,low,high,mid);
    }
}
// Merge sort 
void merge(int *arr, int low, int high, int mid)
{
    int i, j, k, c[50];
    i = low;
    k = low;
    j = mid + 1;
    while (i <= mid && j <= high) {
        if (arr[i] < arr[j]) {
            c[k] = arr[i];
            k++;
            i++;
        }
        else  {
            c[k] = arr[j];
            k++;
            j++;
        }
    }
    while (i <= mid) {
        c[k] = arr[i];
        k++;
        i++;
    }
    while (j <= high) {
        c[k] = arr[j];
        k++;
        j++;
    }
    for (i = low; i < k; i++)  {
        arr[i] = c[i];
    }
}
// read input array and call mergesort
int main()
{
 vector<int>arr_f;
  int count=10;
  for (size_t i = 0 ; i<count; i++)
  {
    arr_f.push_back((int)rand()%100000);
  }
  auto inicio=high_resolution_clock::now();
	//-----------------------
  SelectionSort<int>selsort;
  selsort.sort(arr_f);
  //-----------------------
  cout<<endl<<"Sorted"<<endl;
  print_vec(arr_f,10);
	auto fin=high_resolution_clock::now();
	auto tiempo=duration_cast<microseconds>(fin - inicio).count();
	cout<<"tiempo en micro segundos: "<<tiempo<<endl;
  
  return 0;

    /*cout<<"Enter number of elements to be sorted:";
    cin>>num;
    cout<<"Enter "<<num<<" elements to be sorted:";
    for (int i = 0; i < num; i++) 
    {
       cin>>myarray[i];
    }
    merge_sort(myarray, 0, num-1);
    cout<<"Sorted array\n";
    for (int i = 0; i < num; i++)
    {
        cout<<myarray[i]<<"\t";
    }*/
}