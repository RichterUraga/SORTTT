#include<iostream>
using namespace std;
template <typename T>
class Sorter
{
    public:
    Sorter() {};
    ~Sorter() {};

    void swap(int i, int j, std::vector<T> &arr)
    {
        T aux = arr[i];
        arr[i] = arr[j];
        arr[j] = aux;
    };

    virtual void sort(std::vector<T> &arr) {};
};
template <typename T>
class BubbleSort : public Sorter<T>
{
  public:
  BubbleSort() {};
  ~BubbleSort(){};
  bool no_swap;
  void sort(std::vector<T>&arr)
  {
    for(size_t i =0; i<arr.size();i++)
    {
      no_swap= true;
      for(size_t j =0; j<arr.size()-i-1;j++)
      {
        if (arr[j]>arr[j+1])
        {
          Sorter<T>::swap(j,j+1, arr);
          no_swap= false;
        }
      }
      if (no_swap)
      break;
    }
  };
};