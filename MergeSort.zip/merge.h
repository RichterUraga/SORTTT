#include<iostream>
using namespace std;

template <typename T>
class MergeSort : public Sorter<T>
{
    public:
    MergeSort() {};
    ~MergeSort() {};

    void sort(std::vector<T> &arr)
    {
      mergesort(arr, 0 , arr.size()-1);
    };
  void mergesort(std::vector<T> &arr, int l, r)
  {
    if(l<r){
      int m= l+(l+r)/2;
      mergesort(arr,l,m);
      mergesort(arr, m+1, r);

      merge(arr,l,r);
    }
  }
  void merge(std::vector<T> &arr , int l, int m, int r)
  {
     int i, j, k, c[50];
    i = l;
    k = l;
    j = m + 1;
    while (i <= m && j <= r) {
        if (arr[i] < arr[j]) {
            c[k] = arr[i];
            k++;
            i++;
        }
        else  {
            c[k] = arr[j];
            k++;
            j++;
        }
    }
    while (i <= m) {
        c[k] = arr[i];
        k++;
        i++;
    }
    while (j <= r) {
        c[k] = arr[j];
        k++;
        j++;
    }
    for (i = l; i < k; i++)  {
        arr[i] = c[i];
    }
  }
};